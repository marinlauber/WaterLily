using WaterLily
include("TwoD_plots.jl")
function circle(n,m;Re=250,U=1)
    radius, center = m/16, m/2
    body = AutoBody((x,t)->√sum(abs2, x .- center) - radius)
    Simulation((n,m), (U,0), radius; ν=U*radius/Re, body, exitBC=false)
end

sim = circle(3*2^8,2^9)
# sim = circle(3*2^7,2^8)
# sim = circle(3*2^6,2^7)
t₀ = round(sim_time(sim))
duration = 10
tstep = 0.1
R = inside(sim.flow.p)
@time @gif for tᵢ in range(t₀,t₀+duration;step=tstep)
    sim_step!(sim,tᵢ)
    @inside sim.flow.σ[I] = WaterLily.curl(3,I,sim.flow.u)*sim.L/sim.U
    flood(sim.flow.σ[R]; clims=(-5,5)); body_plot!(sim)
    contour!(sim.flow.p[R]',levels=range(-1,1,length=10),color=:black,linewidth=0.5,legend=:none)
    println("tU/L=",round(tᵢ,digits=4),
        ", Δt=",round(sim.flow.Δt[end],digits=3))
end